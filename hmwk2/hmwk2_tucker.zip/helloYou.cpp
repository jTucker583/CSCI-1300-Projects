// helloYou.cpp

// CSCI 1300 Fall 2022
// Author: Jakob Tucker
// Recitation: 102 – Ojasvi Bhalerao
// Homework 2 - Problem #2

#include <iostream>
using namespace std;

string name = "";
int main()
{
    cout << "Please enter your name below: " << endl;
    cin >> name;
    cout << "Hello, " << name << "!" << endl;
    return 0;
}