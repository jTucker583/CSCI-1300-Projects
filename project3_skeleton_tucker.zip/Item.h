#ifndef ITEM_H
#define ITEM_H
#include <iostream>
using namespace std;

class Item
{
public:
    // constructors
    Item();
    Item(string type, string name);
    Item(string type, string name, int amount);
    // getter functions
    string getType() const;
    string getName() const;
    int getAmount() const;

    // setter functions
    void setType(string type);
    void setName(string name);
    void setAmount(int amount);

private:
    string type_;
    string name_; // intended to be used for specifying weapons and cookingware, without creating a class specifically for them
    int amount_;
};
#endif