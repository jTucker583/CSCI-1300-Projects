#include "Player.h"
#include "Item.h"
#include "Monster.h"
#include "NPC.h"
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <ctime>
#include <vector>

// BASIC FUNTIONS (Display Merchant Menu, Display map, Dispaly status, Split, Read Monster,
//                 Read Riddle, Append Results file, Append Leaderboard file, display riddle,
//                 display endgame results, fight monster, decide random misfortune)

// displays a list of items that can be purchased.
// implement list vector and loop through until the user has finished purchasing
void displayMerchantMenu(vector<Item> &items)
{
}

// display the current poision of the player and postion of rooms and discovered NPC's using the map class
// to be called every time an action is made in main().
void displayMap()
{
}

// display the hunger and armour capabilities of each party member
// to be called every time an action is made in main().
void displayStatus()
{
}

// taken from homework 5, takes in a string and splits it into array parts
int split(string input, char delimator, string array[], int size)
{
    string temp = "";
    int counter = 0;
    int input_length = input.length();
    int array_counter = 1;

    if (input_length == 0) // if there is an empty input, there should be no values inside the array.
    {
        array_counter = 0;
    }
    for (int i = 0; i < input_length; i++) // check if input string is larger than array
    {
        if (input[i] == delimator)
        {
            counter++;
        }
    }
    if (counter == 0 && size > 0) // if there is no delimators, and the array is greater than 0, the first element is the input.
    {
        array[0] = input;
        return array_counter;
    }

    for (int i = 0; i < size; i++)
    {
        input_length = input.length();
        temp = "";
        for (int j = 0; j < input_length; j++)
        {
            if (input[j] != delimator)
            {
                temp += input[j];
            }
            else
            {
                input = input.substr(j + 1);
                array_counter++;
                break;
            }
        }
        array[i] = temp;
    }
    if (counter >= size)
    {
        return -1;
    }
    else
    {
        return array_counter;
    }
}

// utilizing split, reads the monster file and appends each monster to the vector by reference.
// if the line is not formatted correctly, the monster will not be added.
int readMonsterFile(string filename, vector<Monster> &monsters)
{
    ifstream file;
    string line;
    int line_length = 2;
    file.open(filename);
    int monster_counter = 0;
    if (file.is_open())
    {
        string current_line[line_length];
        int num_changes = 0;
        while (getline(file, line))
        {
            if (line != "")
            {
                num_changes = split(line, ',', current_line, line_length);
                if (num_changes == line_length) // data validaiton
                {
                    Monster current_monster(current_line[0], stoi(current_line[1]));
                    monsters.push_back(current_monster);
                    monster_counter++;
                }
            }
        }
        return monster_counter;
    }
    else
    {
        return -1;
    }
}
// utilizing split, reads the riddle file and appends each NPC to the vector by reference.
// if the line is not formatted correctly, the NPC will not be added.
// Sets default values in each NPC not specified in the text file.
int readRiddleFile(string filename, vector<NPC> &npcs)
{
    ifstream file;
    string line;
    int line_length = 2;
    file.open(filename);
    int npc_counter = 0;
    if (file.is_open())
    {
        string current_line[line_length];
        int num_changes = 0;
        while (getline(file, line))
        {
            if (line != "")
            {
                num_changes = split(line, '~', current_line, line_length);
                if (num_changes == line_length) // data validaiton
                {
                    NPC current_NPC(current_line[0], current_line[1]);
                    npcs.push_back(current_NPC);
                    npc_counter++;
                }
            }
        }
        return npc_counter;
    }
    else
    {
        return -1;
    }
}

// utilize fstream object to write results of the game, plus the date.
int appendResultsFile(string filename, string leader, int numRooms, int goldPiecesRemaining,
                      vector<Item> treasure, int exploredspaces, int defeatedMonsters, int numTurns, string date)
{
}

// collect all infromation based on the turns, the leader name, gold pieces and such to be displayed at the end of the game.
void displayEndgameResults(string leader, int numRooms, int goldPiecesRemaining, vector<Item> treasure,
                           int exploredspaces, int defeatedMonsters, int numTurns)
{
}

// based on an equation given in the github, determine if fighting a monster leads to victory or defeat.
// if defeat, update stats in each of the player objects, and reduce the treasure in the items vector.
// use rand() to calculate if the monster drops a key if it is defeated.
double fightMonster(vector<Item> weapons, vector<Monster> monsters)
{
}

// utilize the rand function to decide if a misfortune happens, and what that is. Use ints to correspond to a misfortune type
int decideRandomMisfortune()
{
}

// need to utilize a sotrting method and a score calculator to append to the leaderboard and sort the file.
int appendLeaderboard(string resultsfile, string leaderboardfile)
{
}

// to be altered as the program progresses, for now just assert that the vectors of objects is instanciated correctly.
int tester(vector<Player> people, vector<Monster> monsters, vector<NPC> npcs, vector<Item> items)
{
    cout << "////// TESTER FUNCTION //////" << endl;

    cout << "The following numbers should be completely random between 1 and 100: ";
    int max = 100;
    int min = 1;
    for (int i = 0; i < 5; i++)
    {
        cout << rand() % (max - min + 1) + min << ", ";
    }
    cout << endl;

    assert(people.size() == 5);
    cout << "Party members: ";
    for (int i = 0; i < people.size(); i++)
    {
        cout << people.at(i).getName() << ", " << people.at(i).getHunger() << "; ";
    }
    cout << endl;

    cout << "\n ********************** \n"
         << endl;
    cout << "Monsters: (only printin the name)";
    for (int i = 0; i < monsters.size(); i++)
    {
        cout << monsters.at(i).getName() << ", ";
    }
    cout << endl;

    cout << "\n ********************** \n"
         << endl;
    cout << "NPCs (only printing the answer): ";
    for (int i = 0; i < npcs.size(); i++)
    {
        cout << npcs.at(i).getAnswer() << ", ";
    }
    cout << endl;

    cout << "////// END TESTER FUNCTION //////" << endl;
}

// ****** MAIN FUNCTION ****** //

int main()
{
    // initial object creaton
    vector<Player> people;
    vector<Monster> monsters;
    vector<NPC> npcs;
    vector<Item> items;
    string monsters_file = "Monsters.txt";
    string riddles_file = "Riddles.txt";
    // seed the rand() function
    srand(time(0));
    // **************************************************************************** //
    // PHASE 1
    /*
    Ask for player names and instanciate player objects
    Read monster files and put into a monster vector
    Read riddle file and put into a riddle vector
    Instanciate a map object using random numbers (Escape door must be in the last row)
    instanciate items vector
    Display the merchnat menu and change amounts in item inventory based on user input
    */
    // create people vector
    for (int i = 0; i < 5; i++)
    {
        string name;
        if (i != 0)
        {
            cout << "Enter party member " << i << " name:" << endl;
            getline(cin, name);
        }
        else
        {
            cout << "Enter player name:" << endl;
            getline(cin, name);
        }
        Player person(name);
        people.push_back(person);
    }

    // create monsters vector
    int monster_result = readMonsterFile(monsters_file, monsters);
    assert(monster_result == 21);

    // create NPC vector
    int npc_result = readRiddleFile(riddles_file, npcs);
    assert(npc_result == 20);
    tester(people, monsters, npcs, items);
    // **************************************************************************** //
    // PHASE 2
    /*
    In a while loop, present the user with the following options in any normal space:
    1. move
    2. investigate
    3. pick a fight
    4. cook and eat
    5. give up

    If the player is in an NPC occupied space, present them with the following options:
    1. move
    2. speak to the NPC
    3. give up
    If they choose 2, present with a riddle to solve.
    If solved correctly, open the merchant menu
    If not, fight a monster

    If the player is in a room occupied space, present them with the following options:
    1. move
    2. open the door (PLAYER MUST HAVE A KEY)
    3. give up
    */
    // note: player needs to have keys to open the door. They can get them by pissing off an NPC, or simply picking a fight.

    // **************************************************************************** //
    // PHASE 3
    /*
    1. make phase three its own function
    2. state the reason for the end of game
    3. use a conditional to display an end of game congratulatory or game over message,
    along with reasoning as to why the game was won or lost
    4. print end of game statistics described in the github.
    */
    return 0;
}